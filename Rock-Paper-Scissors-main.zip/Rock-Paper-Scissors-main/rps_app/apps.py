from django.apps import AppConfig


class RpsAppConfig(AppConfig):
    name = 'rps_app'
